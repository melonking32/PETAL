import time

time.sleep(5000)